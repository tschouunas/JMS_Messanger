package adminservice;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * 
 * 
 * @author wir 
 *
 */

@ApplicationPath("/AdminService")
public class AdminApplication extends Application {
}
